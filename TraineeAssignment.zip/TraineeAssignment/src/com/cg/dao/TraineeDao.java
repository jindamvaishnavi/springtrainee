package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Trainee;

public interface TraineeDao extends JpaRepository<Trainee,Integer> {

}
