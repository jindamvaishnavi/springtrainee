package com.cg.service;

import java.util.List;

import com.cg.beans.Trainee;
import com.cg.exception.TraineeNotFoundException;
import com.cg.exception.TraineeServicesDownException;

public interface ITraineeService {

	public List<Trainee> getAllTrainees() throws TraineeServicesDownException;
	public Trainee getTraineeInfo(int traineeId) throws TraineeNotFoundException,TraineeServicesDownException;
	public Trainee addTrainee(Trainee trainee)throws TraineeServicesDownException;
	 public Trainee deleteTrainee(int traineeId)throws TraineeNotFoundException,TraineeServicesDownException;
	 public Trainee updateTrainee(Trainee trainee)throws TraineeNotFoundException,TraineeServicesDownException;
}
